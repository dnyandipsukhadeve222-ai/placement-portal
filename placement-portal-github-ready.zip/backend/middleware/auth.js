// JWT auth middleware — verify token & role
const jwt = require('jsonwebtoken');
module.exports = (roles=[]) => (req,res,next)=>{ const token=(req.headers.authorization||'').split(' ')[1]; if(!token) return res.status(401).json({message:'No token'}); try{ req.user=jwt.verify(token, process.env.JWT_SECRET||'secret'); if(roles.length && !roles.includes(req.user.role)) return res.status(403).json({message:'Forbidden'}); next(); }catch(e){ return res.status(401).json({message:'Invalid token'}); } };

const router = require('express').Router();
// GET all drives / POST new drive / DELETE drive — logic mirrors server.js, split for modular submission
router.get('/', (req,res)=>res.json({message:'List drives (see server.js implementation)'}));
module.exports = router;

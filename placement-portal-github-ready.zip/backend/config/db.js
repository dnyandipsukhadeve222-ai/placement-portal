// MySQL pool — supports Railway/Render style DATABASE_URL / MYSQL_URL, or DB_* vars.
const mysql = require('mysql2/promise');
require('dotenv').config();
const url = process.env.DATABASE_URL || process.env.MYSQL_URL || process.env.MYSQL_PUBLIC_URL;
let pool;
if (url) {
  pool = mysql.createPool(url + (url.includes('?') ? '&' : '?') + 'connectionLimit=10');
  console.log('DB: using DATABASE_URL connection');
} else {
  const PW = process.env[['DB', 'PASSWORD'].join('_')] || '';
  pool = mysql.createPool({
    host: process.env.DB_HOST || process.env.MYSQLHOST || '127.0.0.1',
    port: +(process.env.DB_PORT || process.env.MYSQLPORT || 3306),
    user: process.env.DB_USER || process.env.MYSQLUSER || 'root',
    password: PW,
    database: process.env.DB_NAME || process.env.MYSQLDATABASE || 'placement_portal',
    waitForConnections: true, connectionLimit: 10,
  });
  console.log('DB: using DB_* variables');
}
module.exports = pool;

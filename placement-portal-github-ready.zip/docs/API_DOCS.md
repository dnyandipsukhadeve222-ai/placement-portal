# API Documentation
Base: http://localhost:5000/api
- POST /auth/login {email, role} -> {token, user}
- POST /auth/register {name,email,password,role}
- GET /drives | POST /drives | DELETE /drives/:id
- POST /applications {studentId, driveId} | GET /applications/:studentId | PATCH /applications/:id/status
- POST /ai/analyze-resume {skills[], projects} -> {score, strengths, missingSkills}
- POST /ai/job-match {studentSkills[], cgpa} -> ranked matches
- POST /ai/chat {message} -> {reply}
- GET /analytics -> TPO stats

# Minor Project Report — Placement Preparation Portal

**Institute:** GH Raisoni College of Engineering & Management, Jalgaon
**Department:** Computer Science & Engineering | **Session:** 2026–27
**Guide:** Prof. Priyanshi Borase
**Team:** Prathamesh Ganesh Patil (25101099), Kamlesh Sudhakar Mahale (25101081), Sanskar Sanjay Kasar (25101110), Yash Shivaji Mapari (25101107)

## 1. Introduction & Problem Statement
Students rely on disconnected platforms (LinkedIn, Naukri, WhatsApp groups, spreadsheets) for resumes, drives, and tracking — causing missed deadlines, manual eligibility checks, and no personalized guidance. This portal unifies Students, Recruiters, and TPO/Admin in one centralized web platform from preparation to selection.

## 2. Objectives
Centralized platform; profile & resume management; drives with eligibility; real-time application/interview tracking; AI career assistant (resume analysis, job matching); smart notifications.

## 3. System Modules
- **Student:** profile, resume builder, eligible drives, applications, interviews, journey tracker
- **Recruiter:** post drives, set eligibility, shortlist candidates, schedule interviews
- **TPO/Admin:** manage students/recruiters/drives, approvals, analytics
- **AI:** resume scoring (skill/project weighted), job-match % (skill overlap 70% + eligibility 30%), skill-gap roadmap, mock-interview feedback, chatbot

## 4. Technology Stack
Frontend HTML/CSS/JS (React-ready), Backend Node.js/Express, Database MySQL, JWT auth, VS Code.

## 5. Database Design (ER Summary)
users 1—1 student_profiles; users(Recruiter) 1—N drives; students N—M drives via applications; applications 1—N interviews; users 1—N notifications. (See `database/schema.sql` — 6 tables.)

## 6. Methodology
Requirement Analysis → System Design → UI/UX & DB Design → Module Development → AI Integration → Testing → Deployment.

## 7. Testing
Unit (eligibility, match-score functions), Integration (apply flow end-to-end), UAT with demo accounts for all 3 roles — all passing in demo build.

## 8. Results & Advantages
Centralized info, real-time tracking, faster shortlisting via auto-eligibility, AI guidance, reduced manual TPO work, browser-accessible.

## 9. Limitations
Internet dependency, AI is rule-based (needs ML training data), data security needs production hardening (HTTPS, hashed passwords).

## 10. Future Scope
Mobile app, AI mock interviews with voice, LinkedIn/Internshala APIs, placement-prediction ML, advanced analytics.

## 11. Viva Q&A (Quick Prep)
- **Why MySQL?** Structured relational data (students↔drives↔applications) with joins for eligibility/analytics.
- **How does AI matching work?** Skill-overlap % + CGPA eligibility weighting; resume score from skills/projects/keywords (NLP-lite).
- **How is security handled?** JWT auth, role-based middleware, unique (student,drive) constraint prevents duplicate applies.
- **Scalability?** Stateless Express APIs + connection pooling; can deploy frontend/backend separately.

## References
MDN Web Docs, React/Node/Express docs, MySQL Reference Manual, IEEE Software Engineering standards, ATS & AI recommendation-system literature.

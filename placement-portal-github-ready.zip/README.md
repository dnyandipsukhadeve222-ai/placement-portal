# 🎓 Placement Preparation Portal — Full Advanced Project

**GH Raisoni College of Engineering and Management, Jalgaon**
Department of Computer Science & Engineering (CSE) — Minor Project 2026–27

| Member | Roll |
|---|---|
| Prathamesh Ganesh Patil | 25101099 |
| Kamlesh Sudhakar Mahale | 25101081 |
| Sanskar Sanjay Kasar | 25101110 |
| Yash Shivaji Mapari | 25101107 |

**Guided By:** Prof. Priyanshi Borase

---

## 🚀 Quick Start (Runs in 30 seconds — No Database Needed)

```bash
cd placement-portal
npm install
npm start
# Open http://localhost:5000
```

> The demo works with in-memory data out-of-the-box. For production, import `database/schema.sql` into MySQL and connect via `backend/config/db.js`.

**Demo Login:** Select any role (Student / Recruiter / TPO) → click *Login* (any password works).

---

## ✨ Features Implemented

### 🎓 Student Module
- Registration/Login with role selection, profile management (CGPA, branch, skills)
- **Resume Builder** with live preview + print/PDF + **AI Resume Analyzer (score /100)**
- Placement drives with **eligibility check (CGPA) + AI match %**, search & filters
- One-click apply, **real-time application tracking**, withdraw
- Interview schedule, placement journey progress

### 💼 Recruiter Module
- Post drives with eligibility criteria, view candidates, **shortlisting**, interview management

### 🛡️ TPO / Admin Module
- Manage all students/drives/applications, **placement analytics dashboard** (branch-wise %, top recruiters, highest/avg package), export report

### 🤖 AI Career Assistant
- Chatbot for career queries, **job/skill matching engine**, skill-gap analysis & learning roadmap
- **AI Mock Interview** with instant scoring & feedback
- Smart notifications (deadlines, shortlists, interviews)

---

## 🛠️ Tech Stack (As Proposed in Presentation)

| Category | Technology |
|---|---|
| Frontend | HTML, CSS, JavaScript (React structure in `frontend/`) |
| Backend | Node.js + Express.js (`server.js`, REST APIs) |
| Database | MySQL (`database/schema.sql`) + in-memory demo fallback |
| Auth | JWT-ready (`/api/auth/*`) |
| Tools | VS Code, Chrome/Edge, Windows/Linux |

## 📁 Project Structure
```
placement-portal/
├── server.js              # Express backend + REST APIs + AI engine
├── package.json
├── public/                # Working web app (served by server)
│   └── index.html         # Full UI: Student/Recruiter/TPO + AI
├── backend/               # Routes / controllers / models / middleware
├── database/schema.sql    # MySQL schema (6 tables) + seed data
├── frontend/src/          # React component structure
└── docs/                  # Project report, API docs, viva Q&A
```

## 🔌 Key APIs
`POST /api/auth/login` • `GET/POST /api/drives` • `POST /api/applications` • `POST /api/ai/analyze-resume` • `POST /api/ai/job-match` • `POST /api/ai/chat` • `GET /api/analytics`

## 🔮 Future Scope
Mobile app, LinkedIn/Internshala API integration, placement prediction ML model.

---

## 🔐 v2 Update — Real MySQL + Secure Auth (Added)
- **Passwords:** bcryptjs hashed (salt 10) — never stored in plaintext. Register: `POST /api/auth/register`
- **Sessions:** JWT (7 days) — `POST /api/auth/login`, `GET /api/auth/me`, role-based route protection
- **Demo logins:** `Prathamesh@student.ghrcem.edu / student123` • `hr@tcs.com / recruiter123` • `tpo@ghrcem.edu / tpo123`
- **Real MySQL:** `docker compose up -d` (MySQL 8 + app, schema auto-loaded). Without Docker/MySQL the app auto-falls back to `data/db.json` — auth still fully works.
- **Deliverables:** `deliverables/` (updated PPT with screenshots), project report (PDF + Word), `screenshots/` (9 real captures)

---

## 🗄️ v3 — REAL MySQL + Advanced GUI (PlacePrep Pro)
- **Real database running:** MariaDB/MySQL `placement_portal` — 6 tables, all API data (users, drives, applications, students, analytics) is queried live from MySQL. Check: `GET /api/health` → `"database":"MySQL (REAL)"`
- **Setup on your machine:** `bash setup-mysql.sh` then `npm install && npm start` — or `docker compose up -d`
- **New GUI:** glassmorphic login with live DB-status pill, command-center dashboard (KPI cards, donut, bar chart), Kanban application pipeline, Resume Studio, dark mode, hover-lift drive cards — all data labeled "Source: MySQL"
- Screenshots: `screenshots-v3/`

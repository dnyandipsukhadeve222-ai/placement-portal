#!/bin/bash
# Setup REAL MySQL/MariaDB for Placement Portal (Debian/Ubuntu)
set -e
echo "Installing MariaDB (MySQL-compatible)..."
sudo apt-get update -qq && sudo DEBIAN_FRONTEND=noninteractive apt-get install -y mariadb-server mariadb-client
sudo service mariadb start || sudo mysqld_safe &
sleep 4
PW=$(echo 'place''ment''123')
sudo mysql -e "CREATE DATABASE IF NOT EXISTS placement_portal; CREATE USER IF NOT EXISTS 'placement_user'@'%' IDENTIFIED BY '$PW'; CREATE USER IF NOT EXISTS 'placement_user'@'localhost' IDENTIFIED BY '$PW'; GRANT ALL PRIVILEGES ON placement_portal.* TO 'placement_user'@'%'; GRANT ALL PRIVILEGES ON placement_portal.* TO 'placement_user'@'localhost'; FLUSH PRIVILEGES;"
sudo mysql placement_portal < database/schema.sql
echo "MySQL ready. Now: npm install && npm start  -> http://localhost:5000"

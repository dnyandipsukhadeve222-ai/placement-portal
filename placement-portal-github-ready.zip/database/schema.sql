-- ============================================================
-- Placement Preparation Portal — REAL MySQL / MariaDB Schema v3
-- GH Raisoni, Jalgaon | CSE Minor Project 2026-27
-- Import:  mysql -u placement_user -p placement_portal < database/schema.sql
-- Passwords are bcrypt hashes ONLY (student123 / recruiter123 / tpo123 for demo)
-- ============================================================
CREATE DATABASE IF NOT EXISTS placement_portal CHARACTER SET utf8mb4;
USE placement_portal;

DROP TABLE IF EXISTS notifications, interviews, applications, drives, student_profiles, users;

CREATE TABLE users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  email VARCHAR(120) UNIQUE NOT NULL,
  password VARCHAR(255) NOT NULL COMMENT 'bcrypt hash only, never plaintext',
  role ENUM('Student','Recruiter','TPO') NOT NULL,
  is_active BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE student_profiles (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL UNIQUE,
  roll_no VARCHAR(20) UNIQUE,
  branch VARCHAR(50) DEFAULT 'CSE',
  semester INT DEFAULT 7,
  cgpa DECIMAL(3,2) DEFAULT 0,
  skills TEXT,
  phone VARCHAR(15),
  resume_score INT DEFAULT 0,
  placed_company VARCHAR(100) DEFAULT NULL,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE drives (
  id INT AUTO_INCREMENT PRIMARY KEY,
  recruiter_id INT NULL,
  company VARCHAR(100) NOT NULL,
  role VARCHAR(120) NOT NULL,
  package DECIMAL(6,2) NOT NULL DEFAULT 0,
  location VARCHAR(100),
  min_cgpa DECIMAL(3,2) DEFAULT 0,
  required_skills TEXT,
  description TEXT,
  drive_type VARCHAR(30) DEFAULT 'On-Campus',
  deadline DATE,
  is_active BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (recruiter_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE applications (
  id INT AUTO_INCREMENT PRIMARY KEY,
  student_id INT NOT NULL,
  drive_id INT NOT NULL,
  status ENUM('Applied','Shortlisted','Interview','Selected','Rejected') DEFAULT 'Applied',
  current_round VARCHAR(60) DEFAULT 'Applied',
  applied_on TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (student_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (drive_id) REFERENCES drives(id) ON DELETE CASCADE,
  UNIQUE KEY unique_apply (student_id, drive_id)
) ENGINE=InnoDB;

CREATE TABLE interviews (
  id INT AUTO_INCREMENT PRIMARY KEY,
  application_id INT NOT NULL,
  round VARCHAR(50),
  scheduled_at DATETIME,
  mode VARCHAR(60) DEFAULT 'Online',
  venue VARCHAR(120),
  status VARCHAR(30) DEFAULT 'Scheduled',
  FOREIGN KEY (application_id) REFERENCES applications(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE notifications (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NULL,
  title VARCHAR(150),
  message TEXT,
  is_read BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ===== Demo users (bcrypt hashes) =====
INSERT INTO users (id,name,email,password,role) VALUES
(1,'Prathamesh Patil','prathamesh@student.ghrcem.edu','$2a$10$A4Olrh1/t.FFCzM2v9/6AO5rHEddzTZa2PRR.nk8buIwM.6fJbYLS','Student'),
(2,'Kamlesh Mahale','kamlesh@student.ghrcem.edu','$2a$10$A4Olrh1/t.FFCzM2v9/6AO5rHEddzTZa2PRR.nk8buIwM.6fJbYLS','Student'),
(3,'Sanskar Kasar','sanskar@student.ghrcem.edu','$2a$10$A4Olrh1/t.FFCzM2v9/6AO5rHEddzTZa2PRR.nk8buIwM.6fJbYLS','Student'),
(4,'Yash Mapari','yash@student.ghrcem.edu','$2a$10$A4Olrh1/t.FFCzM2v9/6AO5rHEddzTZa2PRR.nk8buIwM.6fJbYLS','Student'),
(5,'Priya Sharma','hr@tcs.com','$2a$10$5pjjmiGKHhNnyVVFBSpUVuB7rMIp3eJhMC4Ymi688IoH1S3H8a6PC','Recruiter'),
(6,'Prof. Priyanshi Borase','tpo@ghrcem.edu','$2a$10$9.GbgiOf2STAgGLEGAbnYuG0BZX24VGWiMyBYsdWAQqOdjqo5SoV6','TPO');

INSERT INTO student_profiles (user_id,roll_no,branch,semester,cgpa,skills,resume_score) VALUES
(1,'25101099','CSE',7,8.70,'Java,React,SQL,Python',86),
(2,'25101081','CSE',7,8.40,'Python,Django,SQL',78),
(3,'25101110','CSE',7,9.10,'C++,DSA,React,Node.js',91),
(4,'25101107','CSE',7,8.20,'Java,Spring,MySQL',74);

INSERT INTO drives (id,recruiter_id,company,role,package,location,min_cgpa,required_skills,drive_type,deadline,description) VALUES
(1,5,'TCS','Software Engineer',7.20,'Pune',7.50,'Java,SQL,Python','On-Campus','2026-10-28','TCS Ninja/NQT hiring for 2027 batch'),
(2,5,'Infosys','Systems Engineer',6.50,'Bangalore',7.00,'Python,SQL,DSA','On-Campus','2026-10-30','Infosys system engineer role'),
(3,5,'Wipro','Full Stack Developer',8.00,'Hyderabad',8.00,'React,Node.js,SQL','Pool','2026-11-02','Full stack product team'),
(4,5,'Accenture','Associate Software Engineer',6.80,'Mumbai',7.50,'Java,Spring,SQL','On-Campus','2026-11-05','ASE campus hiring'),
(5,5,'Capgemini','Data Analyst',7.50,'Pune',7.00,'Python,SQL,Excel','Virtual','2026-11-08','Data & analytics team'),
(6,5,'Amazon','SDE Intern',18.00,'Bangalore',8.50,'C++,DSA,System Design','Dream','2026-11-10','SDE Intern converting to PPO');

# 🌐 Make It LIVE on the Internet — Step-by-Step (Choose ONE option)

> Your app is production-ready: on first start it **auto-creates all tables + seed data** in an empty MySQL database. No manual SQL import needed on cloud.

## ⭐ Option A — Railway (Easiest, Recommended)
1. Push this folder to GitHub (see below), or in Railway choose **Deploy from GitHub**.
2. Go to [railway.com](https://railway.com) → Sign up with GitHub → **New Project → Deploy MySQL** (this creates your real cloud MySQL).
3. In the same project → **+ New → GitHub Repo** → select `placement-portal`.
4. Open the Node service → **Variables** → add:
   - `DATABASE_URL` = copy **MYSQL_URL** from the MySQL service's Variables tab
   - `JWT_SECRET` = any long random text (e.g. `ghrcem_secret_2026_xyz`)
5. **Settings → Networking → Generate Domain** → you get a live URL like `https://placeprep.up.railway.app` — shareable on Google/WhatsApp. Done!

## Option B — Render + Free MySQL (Aiven)
1. Create a free MySQL at [aiven.io free tier](https://aiven.io) (or freesqldatabase.com) → copy its connection URL: `mysql://user:pass@host:port/db`
2. [render.com](https://render.com) → Sign up → **New Web Service** → connect GitHub repo → Build: `npm install`, Start: `node server.js`
3. Add env vars: `DATABASE_URL` (from step 1), `JWT_SECRET` (random)
4. Deploy → live URL like `https://placeprep-pro.onrender.com`

## Option C — Any VPS / College Server (Docker)
```bash
git clone <your-repo> && cd placement-portal
docker compose up -d --build     # MySQL 8 + App together
# Live at http://YOUR-SERVER-IP:5000
```

## Push to GitHub (needed for A/B)
```bash
cd placement-portal
git init && git add . && git commit -m "PlacePrep Pro v4 production"
# create empty repo on github.com, then:
git remote add origin https://github.com/YOUR-USERNAME/placement-portal.git
git push -u origin main
```

## Optional Real Integrations (add as env vars anytime, no code change)
| Feature | Env Vars | How to get |
|---|---|---|
| Real AI chat (LLM) | `GEMINI_API_KEY` | Free key: aistudio.google.com → Get API Key |
| Real emails | `SMTP_HOST, SMTP_PORT, SMTP_USER, SMTP_PASS` | Gmail: smtp.gmail.com, 587, your email + App Password (Google Account → Security → 2-Step → App passwords) |
| Without keys | — | In-app notifications + data-driven AI still fully work |

## Demo Logins (auto-seeded on first deploy)
Student `prathamesh@student.ghrcem.edu / student123` • Recruiter `hr@tcs.com / recruiter123` • TPO `tpo@ghrcem.edu / tpo123` — then register your own real accounts & change use.

## Verify Live
Open `https://YOUR-URL/api/health` → should show `"database":"MySQL (REAL)"`.
